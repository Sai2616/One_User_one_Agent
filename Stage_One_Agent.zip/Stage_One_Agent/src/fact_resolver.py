
def resolve_dialect(app_dialect, profile_dialect=None):
    """Resolve dialect using the current app setting."""

    app_value = (
        app_dialect.strip()
        if isinstance(app_dialect, str) and app_dialect.strip()
        else None
    )

    profile_value = (
        profile_dialect.strip()
        if isinstance(profile_dialect, str) and profile_dialect.strip()
        else None
    )

    conflicts = []

    if app_value and profile_value and app_value != profile_value:
        conflicts.append({
            "field": "dialect",
            "app_setting": app_value,
            "profile": profile_value,
            "resolution": "current_app_setting",
        })

    if app_value:
        return {
            "value": app_value,
            "source": "app_setting",
            "conflicts": conflicts,
            "reason": "The current app setting determines the dialect shown.",
        }

    if profile_value:
        return {
            "value": profile_value,
            "source": "profile",
            "conflicts": conflicts,
            "reason": "No current app dialect was available; using the profile.",
        }

    return {
        "value": None,
        "source": None,
        "conflicts": conflicts,
        "reason": "No reliable dialect value is available.",
    }
