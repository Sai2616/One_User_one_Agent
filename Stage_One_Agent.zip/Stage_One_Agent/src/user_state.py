
def build_user_state(user_id, profiles_by_user, events):
    """Build an initial state for one user."""

    profile_result = profiles_by_user.get(user_id, {})
    profile = profile_result.get("profile")

    user_events = [
        event
        for event in events
        if event.get("user_id") == user_id
    ]

    # Sort by trustworthy server-received time.
    # Events with missing timestamps are retained at the end.
    user_events.sort(
        key=lambda event: (
            not bool(event.get("received_at")),
            event.get("received_at") or "",
        )
    )

    return {
        "user_id": user_id,
        "profile": profile,
        "profile_source": "profiles_snapshot"
        if profile is not None else None,
        "profile_reason": profile_result.get(
            "reason", "No profile resolution information."
        ),
        "events": user_events,
        "event_count": len(user_events),
        "facts": {},
        "conflicts": [],
    }
