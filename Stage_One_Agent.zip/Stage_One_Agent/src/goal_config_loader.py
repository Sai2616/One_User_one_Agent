
import json
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parent.parent

DEFAULT_GOALS_FILE = (
    PROJECT_ROOT
    / "one_user_one_agent_pack"
    / "config"
    / "goals.json"
)


def load_goal_config(file_path=DEFAULT_GOALS_FILE):
    """Load and validate the top-level structure of goals.json."""

    file_path = Path(file_path)

    if not file_path.is_file():
        raise FileNotFoundError(
            f"Goal configuration not found: {file_path}"
        )

    try:
        with file_path.open("r", encoding="utf-8") as file:
            config = json.load(file)
    except json.JSONDecodeError as exc:
        raise ValueError(
            f"Invalid JSON in goal configuration: {exc}"
        ) from exc

    if isinstance(config, list):
        goals = config
    elif isinstance(config, dict):
        goals = config.get("goals")
    else:
        goals = None

    if not isinstance(goals, list):
        raise ValueError(
            "Expected a list of goals or an object containing a 'goals' list."
        )

    if not all(isinstance(goal, dict) for goal in goals):
        raise ValueError("Every goal entry must be a JSON object.")

    return goals
