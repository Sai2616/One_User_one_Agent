
import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path


class AgentStore:
    """Persist per-user agent state and decision history in SQLite."""

    def __init__(self, db_path="sample_run/agent_memory.db"):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.initialize()

    def _connect(self):
        return sqlite3.connect(self.db_path)

    def initialize(self):
        """Create the required database tables if they do not exist."""
        connection = self._connect()

        try:
            connection.execute("""
                CREATE TABLE IF NOT EXISTS viewer_state (
                    viewer_id TEXT PRIMARY KEY,
                    state_json TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
            """)

            connection.execute("""
                CREATE TABLE IF NOT EXISTS decisions (
                    decision_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    viewer_id TEXT NOT NULL,
                    trigger_event_id TEXT NOT NULL,
                    decision_json TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    UNIQUE(viewer_id, trigger_event_id)
                )
            """)

            connection.commit()
        finally:
            connection.close()

    def save_viewer_state(self, viewer_id, state):
        """Insert or update a viewer's saved state."""
        if not isinstance(viewer_id, str) or not viewer_id.strip():
            raise ValueError("viewer_id must be a non-empty string.")

        if not isinstance(state, dict):
            raise ValueError("state must be a dictionary.")

        state_json = json.dumps(state)
        updated_at = datetime.now(timezone.utc).isoformat()

        connection = self._connect()

        try:
            connection.execute("""
                INSERT INTO viewer_state
                    (viewer_id, state_json, updated_at)
                VALUES (?, ?, ?)
                ON CONFLICT(viewer_id) DO UPDATE SET
                    state_json = excluded.state_json,
                    updated_at = excluded.updated_at
            """, (viewer_id, state_json, updated_at))

            connection.commit()
        finally:
            connection.close()

    def get_viewer_state(self, viewer_id):
        """Return the saved state, or None if the viewer is new."""
        connection = self._connect()

        try:
            row = connection.execute("""
                SELECT state_json
                FROM viewer_state
                WHERE viewer_id = ?
            """, (viewer_id,)).fetchone()

            if row is None:
                return None

            return json.loads(row[0])
        finally:
            connection.close()

    def record_decision(self, viewer_id, trigger_event_id, decision):
        """
        Save one decision per viewer and trigger event.

        Return True if inserted, or False if already recorded.
        """
        if not isinstance(viewer_id, str) or not viewer_id.strip():
            raise ValueError("viewer_id must be a non-empty string.")

        if not isinstance(trigger_event_id, str) or not trigger_event_id.strip():
            raise ValueError("trigger_event_id must be a non-empty string.")

        if not isinstance(decision, dict):
            raise ValueError("decision must be a dictionary.")

        created_at = datetime.now(timezone.utc).isoformat()
        decision_json = json.dumps(decision)

        connection = self._connect()

        try:
            cursor = connection.execute("""
                INSERT OR IGNORE INTO decisions
                    (viewer_id, trigger_event_id, decision_json, created_at)
                VALUES (?, ?, ?, ?)
            """, (
                viewer_id,
                trigger_event_id,
                decision_json,
                created_at
            ))

            connection.commit()
            return cursor.rowcount == 1
        finally:
            connection.close()

    def get_decisions(self, viewer_id):
        """Return a viewer's saved decisions in insertion order."""
        connection = self._connect()

        try:
            rows = connection.execute("""
                SELECT trigger_event_id, decision_json, created_at
                FROM decisions
                WHERE viewer_id = ?
                ORDER BY decision_id
            """, (viewer_id,)).fetchall()

            return [
                {
                    "trigger_event_id": row[0],
                    "decision": json.loads(row[1]),
                    "created_at": row[2],
                }
                for row in rows
            ]
        finally:
            connection.close()
