
from datetime import datetime, timezone

from src.goal_service import select_goal_for_viewer
from src.goal_planner import create_goal_plan_from_selection


def evaluate_viewer_goal(
    viewer_id,
    viewer_facts,
    measurable_signals,
    window_days_by_goal,
    goals_file=None,
    start_time=None,
):
    """Select and plan one goal for a viewer."""

    if not isinstance(viewer_id, str) or not viewer_id.strip():
        raise ValueError("viewer_id must be a non-empty string.")

    if start_time is None:
        start_time = datetime.now(timezone.utc)

    selection = select_goal_for_viewer(
        viewer_facts=viewer_facts,
        measurable_signals=measurable_signals,
        goals_file=goals_file,
    )

    if selection.get("status") != "ELIGIBLE":
        return {
            "viewer_id": viewer_id,
            "selection": selection,
            "goal_plan": {
                "status": "NO_GOAL",
                "goal": None,
                "reason": selection.get(
                    "reason", "No eligible goal was found."
                ),
            },
        }

    goal = selection["goal"]
    goal_id = goal.get("id")

    if not isinstance(window_days_by_goal, dict):
        window_days_by_goal = {}

    window_days = window_days_by_goal.get(goal_id)

    if window_days is None:
        return {
            "viewer_id": viewer_id,
            "selection": selection,
            "goal_plan": {
                "status": "NO_GOAL",
                "goal": None,
                "reason": (
                    f"No configured goal window was supplied for "
                    f"{goal_id!r}."
                ),
            },
        }

    goal_plan = create_goal_plan_from_selection(
        selection=selection,
        start_time=start_time,
        window_days=window_days,
    )

    return {
        "viewer_id": viewer_id,
        "selection": selection,
        "goal_plan": goal_plan,
    }
