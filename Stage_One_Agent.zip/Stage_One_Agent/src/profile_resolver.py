
from datetime import datetime, timezone


def parse_timestamp(value):
    """Convert an ISO timestamp to UTC."""
    if not isinstance(value, str) or not value.strip():
        return None

    try:
        timestamp = datetime.fromisoformat(
            value.strip().replace("Z", "+00:00")
        )

        if timestamp.tzinfo is None:
            timestamp = timestamp.replace(tzinfo=timezone.utc)

        return timestamp.astimezone(timezone.utc)

    except ValueError:
        return None


def group_profiles_by_user(rows, user_id_field):
    """Group profile rows by user ID."""
    profiles = {}

    for row in rows:
        user_id = row.get(user_id_field)
      
        if not user_id:
            continue

        profiles.setdefault(user_id, []).append(row)

    return profiles


def resolve_profile(profile_rows, timestamp_field):
    """Select the latest profile with a valid timestamp."""
    if not profile_rows:
        return {
            "profile": None,
            "duplicate_count": 0,
            "reason": "No profile found.",
        }

    valid_rows = []

    for index, row in enumerate(profile_rows):
        timestamp = parse_timestamp(row.get(timestamp_field))

        if timestamp is not None:
            valid_rows.append((timestamp, index, row))

    if not valid_rows:
        return {
            "profile": None,
            "duplicate_count": len(profile_rows) - 1,
            "reason": "No profile has a valid timestamp.",
        }

    valid_rows.sort(key=lambda item: (item[0], item[1]))

    return {
        "profile": valid_rows[-1][2],
        "duplicate_count": len(profile_rows) - 1,
        "reason": "Selected the latest valid profile timestamp.",
    }
