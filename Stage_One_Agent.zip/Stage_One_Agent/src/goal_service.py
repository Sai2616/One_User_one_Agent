
from src.goal_config_loader import load_goal_config
from src.goal_planner import select_measurable_goal


def select_goal_for_viewer(
    viewer_facts,
    measurable_signals,
    goals_file=None,
):
    """
    Load configured goals and select one measurable goal.

    This uses the current goal-planner schema. The actual
    configuration must match that schema before production use.
    """
    if goals_file is None:
        goals = load_goal_config()
    else:
        goals = load_goal_config(goals_file)

    selection = select_measurable_goal(
        goals=goals,
        viewer_facts=viewer_facts,
        measurable_signals=measurable_signals,
    )

    return selection
