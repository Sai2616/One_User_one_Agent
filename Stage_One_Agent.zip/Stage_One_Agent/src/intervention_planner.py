
def plan_intervention(goal_plan, eligible_actions, is_holdout=False):
    """
    Propose one intervention for a valid goal.

    eligible_actions must contain only actions that have
    already passed the applicable eligibility and policy checks.
    This function does not publish actions.
    """

    if is_holdout:
        return {
            "action": "NO_ACTION",
            "reason": "User belongs to the holdout group.",
        }

    if not isinstance(goal_plan, dict):
        return {
            "action": "NO_ACTION",
            "reason": "Goal plan is missing or invalid.",
        }

    if goal_plan.get("status") != "PLANNED":
        return {
            "action": "NO_ACTION",
            "reason": "No valid goal is available.",
        }

    if not isinstance(eligible_actions, list) or not eligible_actions:
        return {
            "action": "NO_ACTION",
            "reason": "No verified intervention is available.",
        }

    # The candidates must already have passed independent checks.
    candidate = eligible_actions[0]

    if not isinstance(candidate, dict) or not candidate.get("type"):
        return {
            "action": "NO_ACTION",
            "reason": "The proposed intervention is invalid.",
        }

    return {
        "action": candidate["type"],
        "reason": "Selected the first verified intervention.",
        "goal_id": goal_plan["goal"]["id"],
        "content": candidate.get("content"),
    }
