
import json
from pathlib import Path


def load_events(file_path):
    """Read a JSONL file and return its valid event records."""

    events = []

    with open(file_path, "r", encoding="utf-8") as file:
        for line_number, line in enumerate(file, start=1):
            if not line.strip():
                continue

            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                print(f"Invalid JSON at line {line_number}")
                continue

            if not isinstance(event, dict):
                print(f"Expected an object at line {line_number}")
                continue

            events.append(event)

    return events


def deduplicate_events(events):
    """Remove repeated event IDs and keep the earliest
    server-received record when timestamps are comparable.
    """

    unique_events = []
    event_positions = {}
    duplicate_count = 0

    for event in events:
        event_id = event.get("event_id")

        # Do not discard records without an event ID.
        if not event_id:
            unique_events.append(event)
            continue

        if event_id not in event_positions:
            event_positions[event_id] = len(unique_events)
            unique_events.append(event)
            continue

        duplicate_count += 1

        position = event_positions[event_id]
        existing = unique_events[position]

        old_time = existing.get("received_at")
        new_time = event.get("received_at")

        if (
            isinstance(old_time, str)
            and isinstance(new_time, str)
            and new_time < old_time
        ):
            unique_events[position] = event

    return unique_events, duplicate_count





def inspect_events(events):
    """Print a basic summary of the event records."""

    event_ids = [
        event["event_id"]
        for event in events
        if event.get("event_id")
    ]

    user_ids = {
        event["user_id"]
        for event in events
        if event.get("user_id")
    }

    event_types = {}

    for event in events:
        event_name = event.get("event", "unknown")
        event_types[event_name] = (
            event_types.get(event_name, 0) + 1
        )

    duplicate_count = len(event_ids) - len(set(event_ids))

    print("Total event records:", len(events))
    print("Unique users:", len(user_ids))
    print("Duplicate event IDs:", duplicate_count)
    print("Event types:")

    for name, count in sorted(event_types.items()):
        print(f"  {name}: {count}")



if __name__ == "__main__":
    project_root = Path(__file__).resolve().parent.parent

    events_file = (
        project_root
        / "one_user_one_agent_pack"
        / "data"
        / "events.jsonl"
    )

    events = load_events(events_file)

    print("\n--- Raw data ---")
    inspect_events(events)
    clean_events, duplicate_count = deduplicate_events(events)

    print("\n--- Cleaned data ---")
    print("Original records:", len(events))
    print("Duplicate records detected:", duplicate_count)
    print("Records after deduplication:", len(clean_events))

    inspect_events(clean_events)