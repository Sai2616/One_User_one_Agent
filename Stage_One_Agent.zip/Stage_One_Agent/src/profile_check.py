
import csv
from pathlib import Path

from profile_resolver import (
    group_profiles_by_user,
    resolve_profile,
)


PROJECT_ROOT = Path(__file__).resolve().parent.parent
PROFILE_FILE = (
    PROJECT_ROOT
    / "one_user_one_agent_pack"
    / "data"
    / "profiles_snapshot.csv"
)


def main():
    with open(
        PROFILE_FILE,
        "r",
        encoding="utf-8-sig",
        newline="",
    ) as file:
        reader = csv.DictReader(file)
        rows = list(reader)
        columns = reader.fieldnames

    print("Columns:", columns)
    print("Total profile rows:", len(rows))

    # Stop rather than silently assuming the schema.
    user_field = "user_id"
    if not columns or user_field not in columns:
        print("Please identify the actual user ID column.")
        return

    profiles = group_profiles_by_user(rows, user_field)

    duplicate_users = {
        user_id: user_rows
        for user_id, user_rows in profiles.items()
        if len(user_rows) > 1
    }

    print("Unique users with profiles:", len(profiles))
    print("Users with duplicate profile rows:", len(duplicate_users))

    print("\nExample duplicate user IDs:")
    for user_id in list(duplicate_users)[:5]:
        print(user_id, "rows:", len(duplicate_users[user_id]))

    print("\nNext: identify the actual profile timestamp column.")


if __name__ == "__main__":
    main()
