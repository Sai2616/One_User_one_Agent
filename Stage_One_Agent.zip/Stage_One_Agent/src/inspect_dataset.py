
import csv
from pathlib import Path


def inspect_csv(file_path):
    """Display basic information about a CSV file."""

    print(f"\n--- {file_path.name} ---")

    with open(file_path, "r", encoding="utf-8-sig", newline="") as file:
        reader = csv.DictReader(file)

        print("Columns:", reader.fieldnames)

        rows = list(reader)
        print("Total rows:", len(rows))

        if rows:
            print("First record:")
            for column, value in rows[0].items():
                print(f"  {column}: {value}")


if __name__ == "__main__":
    project_root = Path(__file__).resolve().parent.parent
    data_dir = project_root / "one_user_one_agent_pack" / "data"

    files_to_inspect = [
        "profiles_snapshot.csv",
        "catalogue.csv",
        "episodes.csv",
    ]

    for filename in files_to_inspect:
        file_path = data_dir / filename

        if file_path.exists():
            inspect_csv(file_path)
        else:
            print(f"\nFile not found: {file_path}")
