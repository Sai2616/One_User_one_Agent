
from datetime import datetime, timezone


def parse_received_at(value):
    """Parse received_at and normalize it to UTC."""
    if not isinstance(value, str) or not value.strip():
        return None

    try:
        timestamp = datetime.fromisoformat(
            value.strip().replace("Z", "+00:00")
        )

        if timestamp.tzinfo is None:
            return None

        return timestamp.astimezone(timezone.utc)

    except ValueError:
        return None


def get_app_open_events(events):
    """Return valid app-open triggers in received-time order."""
    candidates = []

    for event in events:
        if not isinstance(event, dict):
            continue

        if event.get("event") != "app_open":
            continue

        user_id = event.get("user_id")
        event_id = event.get("event_id")
        received_at = parse_received_at(
            event.get("received_at")
        )

        if not isinstance(user_id, str) or not user_id.strip():
            continue

        if not isinstance(event_id, str) or not event_id.strip():
            continue

        if received_at is None:
            continue

        candidates.append((received_at, event_id, event))

    candidates.sort(key=lambda item: (item[0], item[1]))

    return [event for _, _, event in candidates]
