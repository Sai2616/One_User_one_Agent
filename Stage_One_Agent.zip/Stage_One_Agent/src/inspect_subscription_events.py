
import json
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
EVENTS_FILE = (
    PROJECT_ROOT
    / "one_user_one_agent_pack"
    / "data"
    / "events.jsonl"
)

with open(EVENTS_FILE, "r", encoding="utf-8") as file:
    for line in file:
        if not line.strip():
            continue

        event = json.loads(line)

        print("Event type:", event.get("event"))
        print("Received at:", event.get("received_at"))
        print("Properties:", event.get("properties"))
        print("-" * 50)
