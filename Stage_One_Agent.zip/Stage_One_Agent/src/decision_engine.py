
from datetime import datetime, timezone
from uuid import uuid4


def build_decision_record(
    viewer_id,
    trigger_event_id,
    goal_plan,
    intervention,
    verification,
    decision_time=None,
    evidence=None,
    dialect=None,
    assumptions=None,
    conflicts=None,
    decided_in_ms=0,
):
    """Build an auditable decision record without executing actions."""

    if not isinstance(viewer_id, str) or not viewer_id.strip():
        raise ValueError("viewer_id must be a non-empty string.")

    if not isinstance(trigger_event_id, str) or not trigger_event_id.strip():
        raise ValueError("trigger_event_id must be a non-empty string.")

    if decision_time is None:
        decision_time = datetime.now(timezone.utc)

    if (
        not isinstance(decision_time, datetime)
        or decision_time.tzinfo is None
    ):
        raise ValueError("decision_time must be timezone-aware.")

    if not isinstance(verification, dict):
        verification = {
            "approved": False,
            "passed": [],
            "failed": ["invalid_verification_result"],
        }

    if not isinstance(intervention, dict):
        intervention = {
            "action": "NO_ACTION",
            "reason": "Intervention plan is missing or invalid.",
        }

    goal = (
        goal_plan.get("goal")
        if isinstance(goal_plan, dict)
        else None
    )

    valid_goal = (
        isinstance(goal_plan, dict)
        and goal_plan.get("status") == "PLANNED"
        and isinstance(goal, dict)
        and bool(goal.get("id"))
    )

    proposed_action = intervention.get("action", "NO_ACTION")

    approved = (
        verification.get("approved") is True
        and valid_goal
        and proposed_action != "NO_ACTION"
    )

    if approved:
        action = proposed_action
        status = "READY_FOR_EXECUTION"
        no_action_reason = None
    else:
        action = "NO_ACTION"
        status = "NO_ACTION"

        if not valid_goal:
            no_action_reason = "No valid measurable goal was established."
        elif verification.get("approved") is not True:
            no_action_reason = "Independent verification did not approve the action."
        else:
            no_action_reason = intervention.get(
                "reason",
                "The planner selected no action.",
            )

    goal_output = None

    if valid_goal:
        goal_output = {
            "id": goal["id"],
            "deadline": goal_plan.get("deadline"),
            "success_signal": goal_plan.get("success_signal"),
        }

    return {
        "decision_id": str(uuid4()),
        "viewer_id": viewer_id,
        "trigger": {
            "event": "app_open",
            "event_id": trigger_event_id,
            "received_at": decision_time.astimezone(
                timezone.utc
            ).isoformat(),
        },
        "goal": goal_output,
        "action": action,
        "no_action_reason": no_action_reason,
        "dialect": dialect or {
            "used": None,
            "source": None,
            "conflicts": [],
        },
        "content": intervention.get("content", []),
        "confidence": 0.0 if not approved else 0.5,
        "confidence_reason": (
            "A conservative baseline; confidence is not yet calibrated."
        ),
        "evidence": evidence or [],
        "assumptions": assumptions or [],
        "conflicts": conflicts or [],
        "checks": {
            "passed": verification.get("passed", []),
            "failed": verification.get("failed", []),
        },
        "decided_in_ms": max(0, decided_in_ms),
        "status": status,
    }
