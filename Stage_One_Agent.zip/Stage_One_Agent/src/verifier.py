
from datetime import datetime, timezone, timedelta

IST = timezone(timedelta(hours=5, minutes=30))

OUTBOUND_MESSAGES = {"PUSH", "WHATSAPP"}


def verify_action(
    action,
    is_holdout,
    has_consent,
    decision_time,
    messages_sent_today,
):
    """
    Verify basic intervention safety rules.

    Returns:
        approved: Boolean
        passed: List of successful checks
        failed: List of failed checks
    """

    passed = []
    failed = []

    if not isinstance(action, str):
        return {
            "approved": False,
            "passed": [],
            "failed": ["invalid_action"],
        }

    if action == "NO_ACTION":
        return {
            "approved": True,
            "passed": ["no_action"],
            "failed": [],
        }

    if action not in {
        "HOME_PAGE", "PUSH",
        "WHATSAPP", "IN_APP_MESSAGE"
    }:
        failed.append("unknown_action")

    if is_holdout:
        failed.append("holdout")
    else:
        passed.append("holdout")

    if action in OUTBOUND_MESSAGES:

        if has_consent is True:
            passed.append("consent")
        else:
            failed.append("consent")

        if (
            not isinstance(decision_time, datetime)
            or decision_time.tzinfo is None
        ):
            failed.append("invalid_decision_time")
        else:
            local_time = decision_time.astimezone(IST)
            hour = local_time.hour

            if hour >= 22 or hour < 8:
                failed.append("quiet_hours")
            else:
                passed.append("quiet_hours")

        if (
            isinstance(messages_sent_today, int)
            and not isinstance(messages_sent_today, bool)
            and messages_sent_today == 0
        ):
            passed.append("frequency_cap")
        else:
            failed.append("frequency_cap")

    return {
        "approved": len(failed) == 0,
        "passed": passed,
        "failed": failed,
    }
