
from datetime import datetime, timezone
from uuid import uuid4

from src.action_verifier import verify_proposed_action


def build_verified_decision(
    viewer_id,
    trigger_event_id,
    goal_plan,
    proposed_action,
    decision_time,
    is_holdout,
    dialect,
    content=None,
    evidence=None,
    assumptions=None,
    conflicts=None,
    has_matching_dialect=True,
    content_available=True,
    push_consent=None,
    whatsapp_consent=None,
    messages_sent_today=None,
    duplicate_action=None,
    policy_approved=True,
):
    """
    Verify a proposed action and create a safe decision record.

    This function prepares a decision record only.
    It does not send messages or publish homepage content.
    """

    evidence = evidence or []
    assumptions = assumptions or []
    conflicts = conflicts or []

    # Validate the goal before approving any non-NO_ACTION proposal.
    goal_is_eligible = (
        isinstance(goal_plan, dict)
        and goal_plan.get("status") == "PLANNED"
        and bool(goal_plan.get("goal_id") or goal_plan.get("goal"))
    )

    verifier_result = verify_proposed_action(
        action=proposed_action,
        decision_time=decision_time,
        is_holdout=is_holdout,
        goal_eligible=goal_is_eligible,
        has_matching_dialect=has_matching_dialect,
        content_available=content_available,
        push_consent=push_consent,
        whatsapp_consent=whatsapp_consent,
        messages_sent_today=messages_sent_today,
        duplicate_action=duplicate_action,
        policy_approved=policy_approved,
    )

    approved = verifier_result["approved"]

    if approved:
        final_action = proposed_action
        status = "READY_FOR_EXECUTION"
        no_action_reason = None
    else:
        final_action = "NO_ACTION"
        status = "NO_ACTION"
        no_action_reason = ", ".join(verifier_result["failed"])

    goal_id = None
    if isinstance(goal_plan, dict):
        goal_id = goal_plan.get("goal_id") or goal_plan.get("goal")

    # Never claim that an action was delivered here.
    return {
        "decision_id": str(uuid4()),
        "viewer_id": viewer_id,
        "trigger_event_id": trigger_event_id,
        "decided_at": (
            decision_time.astimezone(timezone.utc).isoformat()
            if isinstance(decision_time, datetime)
            and decision_time.tzinfo is not None
            else None
        ),
        "goal_id": goal_id,
        "action": final_action,
        "status": status,
        "no_action_reason": no_action_reason,
        "dialect": dialect,
        "content": content,
        "evidence": evidence,
        "assumptions": assumptions,
        "conflicts": conflicts,
        "checks": verifier_result,
        "execution_status": "NOT_EXECUTED",
    }
