
from datetime import datetime, timedelta, timezone


IST = timezone(timedelta(hours=5, minutes=30))

ALLOWED_ACTIONS = {
    "HOME_PAGE",
    "PUSH",
    "WHATSAPP",
    "IN_APP_MESSAGE",
    "NO_ACTION",
}


def verify_proposed_action(
    action,
    decision_time,
    is_holdout,
    goal_eligible,
    has_matching_dialect=True,
    content_available=True,
    push_consent=None,
    whatsapp_consent=None,
    messages_sent_today=None,
    duplicate_action=False,
    policy_approved=True,
):
    """Independently validate an action proposal."""

    passed = []
    failed = []

    if action not in ALLOWED_ACTIONS:
        return {
            "approved": False,
            "passed": [],
            "failed": ["unknown_action"],
        }

    if action == "NO_ACTION":
        return {
            "approved": True,
            "passed": ["no_action_required"],
            "failed": [],
        }

    if is_holdout is None:
        failed.append("holdout_status_unknown")
    elif is_holdout:
        failed.append("holdout")
    else:
        passed.append("holdout")

    if goal_eligible is True:
        passed.append("goal_eligibility")
    else:
        failed.append("goal_eligibility")

    if has_matching_dialect is True:
        passed.append("dialect")
    else:
        failed.append("dialect")

    if content_available is True:
        passed.append("content_availability")
    else:
        failed.append("content_availability")

    if duplicate_action is True:
        failed.append("duplicate_action")
    elif duplicate_action is False:
        passed.append("duplicate_action")
    else:
        failed.append("duplicate_action_status_unknown")

    if policy_approved is True:
        passed.append("policy")
    else:
        failed.append("policy")

    if action in {"PUSH", "WHATSAPP"}:
        consent = (
            push_consent if action == "PUSH"
            else whatsapp_consent
        )

        if consent is True:
            passed.append("consent")
        else:
            failed.append("consent")

        if (
            isinstance(messages_sent_today, int)
            and not isinstance(messages_sent_today, bool)
            and messages_sent_today == 0
        ):
            passed.append("frequency_cap")
        else:
            failed.append("frequency_cap")

        if (
            not isinstance(decision_time, datetime)
            or decision_time.tzinfo is None
        ):
            failed.append("decision_time")
        else:
            local_time = decision_time.astimezone(IST)

            if local_time.hour >= 22 or local_time.hour < 8:
                failed.append("quiet_hours")
            else:
                passed.append("quiet_hours")

    return {
        "approved": len(failed) == 0,
        "passed": passed,
        "failed": failed,
    }
