
ALLOWED_ROW_TYPES = {
    "next_episode",
    "because_you_watched",
    "popular_in_dialect",
    "new_releases",
    "genre",
}

MAX_ROWS = 6
MIN_TITLES_PER_ROW = 3
MAX_TITLES_PER_ROW = 10
PAGE_TTL_MINUTES = 120


def build_homepage(hero_title, proposed_rows):
    """
    Build a homepage from already validated catalogue records.

    Each row must have:
        - type: an allowed row type
        - titles: a list of validated title records

    Returns a homepage proposal or an explicit rejection.
    """

    if not isinstance(hero_title, dict) or not hero_title:
        return {
            "status": "REJECTED",
            "reason": "A valid hero title is required.",
        }

    if not isinstance(proposed_rows, list):
        return {
            "status": "REJECTED",
            "reason": "Rows must be supplied as a list.",
        }

    output_rows = []
    used_slugs = set()

    # The hero title must not appear again in a row.
    hero_slug = hero_title.get("content_slug")

    if not isinstance(hero_slug, str) or not hero_slug.strip():
        return {
            "status": "REJECTED",
            "reason": "Hero title has no valid content_slug.",
        }

    used_slugs.add(hero_slug)

    for row in proposed_rows:
        if len(output_rows) >= MAX_ROWS:
            break

        if not isinstance(row, dict):
            continue

        row_type = row.get("type")
        titles = row.get("titles")

        if row_type not in ALLOWED_ROW_TYPES:
            continue

        if not isinstance(titles, list):
            continue

        valid_titles = []

        for title in titles:
            if not isinstance(title, dict):
                continue

            slug = title.get("content_slug")

            if not isinstance(slug, str) or not slug.strip():
                continue

            if slug in used_slugs:
                continue

            valid_titles.append(title)
            used_slugs.add(slug)

            if len(valid_titles) >= MAX_TITLES_PER_ROW:
                break

        # A row with fewer than three titles is not published.
        if len(valid_titles) < MIN_TITLES_PER_ROW:
            continue

        output_rows.append({
            "type": row_type,
            "titles": valid_titles,
        })

    return {
        "status": "PROPOSED",
        "hero": hero_title,
        "rows": output_rows,
        "ttl_minutes": PAGE_TTL_MINUTES,
        "row_count": len(output_rows),
    }
