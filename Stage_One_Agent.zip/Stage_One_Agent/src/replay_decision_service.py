
from datetime import datetime

from src.verified_decision import build_verified_decision


def evaluate_trigger(event, decision_time=None):
    """
    Evaluate one event and return a safe decision record.

    This first integration uses conservative defaults because
    real profile, consent, holdout and catalogue data must be wired in.
    """

    if not isinstance(event, dict):
        raise ValueError("event must be a dictionary")

    viewer_id = event.get("user_id")
    trigger_event_id = event.get("event_id")

    if not viewer_id or not trigger_event_id:
        raise ValueError("Event must contain user_id and event_id")

    if decision_time is None:
        received_at = event.get("received_at")
        if not received_at:
            raise ValueError("Event must contain received_at")

        decision_time = datetime.fromisoformat(
            received_at.replace("Z", "+00:00")
        )

    if (
        not isinstance(decision_time, datetime)
        or decision_time.tzinfo is None
    ):
        raise ValueError("decision_time must be timezone-aware")

    # Until actual goal configuration and viewer facts are connected,
    # do not invent an eligible goal or authorize an action.
    return build_verified_decision(
        viewer_id=viewer_id,
        trigger_event_id=trigger_event_id,
        goal_plan=None,
        proposed_action="NO_ACTION",
        decision_time=decision_time,
        is_holdout=None,
        dialect=event.get("app_dialect"),
        evidence=[
            {
                "event_id": trigger_event_id,
                "source": "events.jsonl",
                "timestamp_field": "received_at",
                "timestamp": event.get("received_at"),
            }
        ],
        assumptions=[
            "Goal eligibility and viewer facts are not yet integrated."
        ],
        conflicts=[],
        duplicate_action=None,
        policy_approved=False,
    )
