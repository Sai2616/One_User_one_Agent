
from datetime import datetime, timezone

from src.goal_planner import create_goal_plan_from_selection
from src.decision_engine import build_decision_record


def process_goal_decision(
    viewer_id,
    trigger_event_id,
    selection,
    window_days,
    intervention,
    verification,
    start_time=None,
    evidence=None,
    dialect=None,
    assumptions=None,
    conflicts=None,
):
    """Create a goal plan and an auditable decision record."""

    if start_time is None:
        start_time = datetime.now(timezone.utc)

    goal_plan = create_goal_plan_from_selection(
        selection=selection,
        start_time=start_time,
        window_days=window_days,
    )

    decision = build_decision_record(
        viewer_id=viewer_id,
        trigger_event_id=trigger_event_id,
        goal_plan=goal_plan,
        intervention=intervention,
        verification=verification,
        decision_time=start_time,
        evidence=evidence,
        dialect=dialect,
        assumptions=assumptions,
        conflicts=conflicts,
    )

    return {
        "goal_plan": goal_plan,
        "decision": decision,
    }
