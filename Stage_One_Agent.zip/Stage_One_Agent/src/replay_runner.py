
import json
from pathlib import Path

from src.data_loader import load_events
from src.replay_engine import parse_received_at


PROJECT_ROOT = Path(__file__).resolve().parent.parent

EVENTS_FILE = (
    PROJECT_ROOT
    / "one_user_one_agent_pack"
    / "data"
    / "events.jsonl"
)

OUTPUT_FILE = PROJECT_ROOT / "sample_run" / "decisions.jsonl"


def deduplicate_for_replay(events):
    """Keep the first record for each non-empty event ID."""
    seen_ids = set()
    unique_events = []

    for event in events:
        if not isinstance(event, dict):
            continue

        event_id = event.get("event_id")

        if not isinstance(event_id, str) or not event_id.strip():
            continue

        if event_id in seen_ids:
            continue

        seen_ids.add(event_id)
        unique_events.append(event)

    return unique_events


def get_valid_triggers(events):
    """Filter and sort app-open events by trusted receipt time."""
    triggers = []

    for event in events:
        event_name = event.get("event")

        if (
            not isinstance(event_name, str)
            or event_name.strip().lower() != "app_open"
        ):
            continue

        user_id = event.get("user_id")
        event_id = event.get("event_id")
        received_at = parse_received_at(event.get("received_at"))

        if not isinstance(user_id, str) or not user_id.strip():
            continue

        if not isinstance(event_id, str) or not event_id.strip():
            continue

        if received_at is None:
            continue

        triggers.append((received_at, event_id, event))

    triggers.sort(key=lambda item: (item[0], item[1]))

    return [event for _, _, event in triggers]


def run_replay(events_file=EVENTS_FILE, output_file=OUTPUT_FILE):
    """Replay triggers and write preliminary simulation records."""
    events_file = Path(events_file)
    output_file = Path(output_file)

    if not events_file.is_file():
        raise FileNotFoundError(
            f"Events file not found: {events_file}"
        )

    events = load_events(events_file)

    if not isinstance(events, list):
        raise TypeError(
            "load_events() must return a list. "
            f"Received: {type(events).__name__}"
        )

    unique_events = deduplicate_for_replay(events)
    triggers = get_valid_triggers(unique_events)

    output_file.parent.mkdir(parents=True, exist_ok=True)

    records_written = 0

    with output_file.open("w", encoding="utf-8") as file:
        for event in triggers:
            record = {
                "viewer_id": event["user_id"],
                "trigger_event_id": event["event_id"],
                "decision_time": event["received_at"],
                "action": None,
                "status": "NOT_EVALUATED",
                "reason": (
                    "Simulation only: goal planning and "
                    "action verification are not integrated yet."
                ),
                "mode": "simulation",
            }

            file.write(json.dumps(record) + "\n")
            records_written += 1

    return {
        "events_loaded": len(events),
        "unique_events": len(unique_events),
        "app_open_triggers": len(triggers),
        "records_written": records_written,
        "output_file": str(output_file),
    }


if __name__ == "__main__":
    summary = run_replay()

    print("\nReplay summary")
    print("-" * 40)

    for key, value in summary.items():
        print(f"{key}: {value}")
