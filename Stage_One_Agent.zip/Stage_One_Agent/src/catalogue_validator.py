
from datetime import datetime, timezone


def parse_utc(value):
    """Parse an ISO timestamp and normalize it to UTC."""
    if not isinstance(value, str) or not value.strip():
        return None

    try:
        parsed = datetime.fromisoformat(
            value.strip().replace("Z", "+00:00")
        )
    except ValueError:
        return None

    if parsed.tzinfo is None:
        return None

    return parsed.astimezone(timezone.utc)


def is_available(title, publish_time):
    """Return True only when availability is established."""

    if not isinstance(publish_time, datetime):
        return False

    if publish_time.tzinfo is None:
        return False

    publish_time = publish_time.astimezone(timezone.utc)

    start = parse_utc(title.get("available_from"))
    end = parse_utc(title.get("available_until"))

    if start is not None and publish_time < start:
        return False

    if end is not None and publish_time >= end:
        return False

    # Missing or malformed boundaries are not treated as proof
    # that a title is unavailable. Schema validation is still needed.
    if title.get("available_from") and start is None:
        return False

    if title.get("available_until") and end is None:
        return False

    return True


def select_catalogue_titles(
    titles,
    dialect,
    publish_time,
    limit=10,
):
    """Select available titles in the user's actual app dialect."""

    if not isinstance(dialect, str) or not dialect.strip():
        return []

    if not isinstance(publish_time, datetime):
        return []

    if publish_time.tzinfo is None:
        return []

    if not isinstance(limit, int) or isinstance(limit, bool) or limit < 1:
        return []

    selected = []
    seen_slugs = set()

    for title in titles:
        if title.get("dialect") != dialect:
            continue

        slug = title.get("content_slug")

        if not isinstance(slug, str) or not slug.strip():
            continue

        if slug in seen_slugs:
            continue

        if not is_available(title, publish_time):
            continue

        selected.append(title)
        seen_slugs.add(slug)

        if len(selected) >= limit:
            break

    return selected
