
from src.replay_engine import (
    get_app_open_events,
    parse_received_at,
)


def test_events_are_sorted_by_received_at():
    events = [
        {
            "event_id": "e2",
            "user_id": "u1",
            "event": "app_open",
            "received_at": "2026-10-19T10:02:00Z",
        },
        {
            "event_id": "e1",
            "user_id": "u1",
            "event": "app_open",
            "received_at": "2026-10-19T10:01:00Z",
        },
    ]

    result = get_app_open_events(events)

    assert [event["event_id"] for event in result] == [
        "e1", "e2"
    ]


def test_non_app_open_events_are_ignored():
    events = [
        {
            "event_id": "e1",
            "user_id": "u1",
            "event": "episode_play",
            "received_at": "2026-10-19T10:01:00Z",
        }
    ]

    assert get_app_open_events(events) == []


def test_naive_timestamp_is_rejected():
    assert parse_received_at("2026-10-19T10:01:00") is None


def test_missing_user_is_rejected():
    events = [
        {
            "event_id": "e1",
            "event": "app_open",
            "received_at": "2026-10-19T10:01:00Z",
        }
    ]

    assert get_app_open_events(events) == []
