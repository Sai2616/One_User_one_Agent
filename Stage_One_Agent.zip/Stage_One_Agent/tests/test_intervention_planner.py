
from src.intervention_planner import plan_intervention


def test_holdout_users_receive_no_action():
    result = plan_intervention(
        goal_plan={"status": "PLANNED"},
        eligible_actions=[{"type": "HOME_PAGE"}],
        is_holdout=True,
    )

    assert result["action"] == "NO_ACTION"


def test_missing_goal_produces_no_action():
    result = plan_intervention(
        goal_plan={"status": "NO_GOAL"},
        eligible_actions=[{"type": "HOME_PAGE"}],
    )

    assert result["action"] == "NO_ACTION"


def test_empty_actions_produce_no_action():
    result = plan_intervention(
        goal_plan={
            "status": "PLANNED",
            "goal": {"id": "example_goal"},
        },
        eligible_actions=[],
    )

    assert result["action"] == "NO_ACTION"


def test_selects_first_verified_action():
    result = plan_intervention(
        goal_plan={
            "status": "PLANNED",
            "goal": {"id": "example_goal"},
        },
        eligible_actions=[
            {"type": "HOME_PAGE", "content": ["title_1", "title_2", "title_3"]},
            {"type": "IN_APP_MESSAGE"},
        ],
    )

    assert result["action"] == "HOME_PAGE"
    assert result["goal_id"] == "example_goal"
