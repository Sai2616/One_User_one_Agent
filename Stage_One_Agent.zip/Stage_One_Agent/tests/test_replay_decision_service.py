
import pytest

from src.replay_decision_service import evaluate_trigger


def test_event_without_goal_data_produces_no_action():
    event = {
        "event_id": "event_001",
        "user_id": "viewer_001",
        "event": "app_open",
        "received_at": "2026-10-19T08:00:00Z",
        "app_dialect": "Telangana Telugu",
    }

    decision = evaluate_trigger(event)

    assert decision["action"] == "NO_ACTION"
    assert decision["status"] == "NO_ACTION"
    assert decision["execution_status"] == "NOT_EXECUTED"


def test_missing_user_id_is_rejected():
    event = {
        "event_id": "event_002",
        "event": "app_open",
        "received_at": "2026-10-19T08:00:00Z",
    }

    with pytest.raises(ValueError, match="user_id"):
        evaluate_trigger(event)


def test_missing_event_id_is_rejected():
    event = {
        "user_id": "viewer_001",
        "event": "app_open",
        "received_at": "2026-10-19T08:00:00Z",
    }

    with pytest.raises(ValueError, match="event_id"):
        evaluate_trigger(event)


def test_naive_decision_time_is_rejected():
    from datetime import datetime

    event = {
        "event_id": "event_003",
        "user_id": "viewer_001",
        "received_at": "2026-10-19T08:00:00Z",
    }

    with pytest.raises(ValueError, match="timezone-aware"):
        evaluate_trigger(event, datetime(2026, 10, 19, 8, 0))
