
import json

from src.goal_service import select_goal_for_viewer


def test_service_selects_matching_goal(tmp_path):
    goals_file = tmp_path / "goals.json"

    goals_file.write_text(
        json.dumps({
            "goals": [
                {
                    "id": "complete_episode",
                    "eligibility": {"signed_up": True},
                    "success_signal": "episode_completed",
                }
            ]
        }),
        encoding="utf-8",
    )

    result = select_goal_for_viewer(
        viewer_facts={"signed_up": True},
        measurable_signals={"episode_completed"},
        goals_file=goals_file,
    )

    assert result["status"] == "ELIGIBLE"
    assert result["goal"]["id"] == "complete_episode"


def test_service_abstains_when_signal_is_unavailable(tmp_path):
    goals_file = tmp_path / "goals.json"

    goals_file.write_text(
        json.dumps({
            "goals": [
                {
                    "id": "complete_episode",
                    "eligibility": {"signed_up": True},
                    "success_signal": "episode_completed",
                }
            ]
        }),
        encoding="utf-8",
    )

    result = select_goal_for_viewer(
        viewer_facts={"signed_up": True},
        measurable_signals=set(),
        goals_file=goals_file,
    )

    assert result["status"] == "NO_GOAL"
    assert result["goal"] is None
