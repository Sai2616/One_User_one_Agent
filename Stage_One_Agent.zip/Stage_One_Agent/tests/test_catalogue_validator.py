
from datetime import datetime, timezone

from src.catalogue_validator import select_catalogue_titles


def test_selects_only_matching_dialect():
    titles = [
        {
            "title_id": "T1",
            "dialect": "d1",
            "content_slug": "movie-a",
        },
        {
            "title_id": "T2",
            "dialect": "d3",
            "content_slug": "movie-b",
        },
    ]

    result = select_catalogue_titles(
        titles,
        "d3",
        datetime(2026, 10, 19, 10, tzinfo=timezone.utc),
    )

    assert [title["title_id"] for title in result] == ["T2"]


def test_deduplicates_content_slug():
    titles = [
        {
            "title_id": "T1",
            "dialect": "d3",
            "content_slug": "same-movie",
        },
        {
            "title_id": "T2",
            "dialect": "d3",
            "content_slug": "same-movie",
        },
    ]

    result = select_catalogue_titles(
        titles,
        "d3",
        datetime(2026, 10, 19, 10, tzinfo=timezone.utc),
    )

    assert len(result) == 1


def test_excludes_title_not_yet_available():
    titles = [
        {
            "title_id": "T1",
            "dialect": "d3",
            "content_slug": "future-movie",
            "available_from": "2026-10-20T00:00:00Z",
        }
    ]

    result = select_catalogue_titles(
        titles,
        "d3",
        datetime(2026, 10, 19, 10, tzinfo=timezone.utc),
    )

    assert result == []
