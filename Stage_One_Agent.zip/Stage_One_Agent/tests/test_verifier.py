
from datetime import datetime, timezone

from src.verifier import verify_action


def test_holdout_user():
    result = verify_action(
        action="HOME_PAGE",
        is_holdout=True,
        has_consent=False,
        decision_time=datetime.now(timezone.utc),
        messages_sent_today=0,
    )

    assert result["approved"] is False
    assert "holdout" in result["failed"]


def test_message_without_consent():
    result = verify_action(
        action="PUSH",
        is_holdout=False,
        has_consent=False,
        decision_time=datetime(
            2026, 10, 19, 6, 0,
            tzinfo=timezone.utc
        ),
        messages_sent_today=0,
    )

    assert result["approved"] is False
    assert "consent" in result["failed"]


def test_quiet_hours():
    result = verify_action(
        action="WHATSAPP",
        is_holdout=False,
        has_consent=True,
        decision_time=datetime(
            2026, 10, 19, 18, 0,
            tzinfo=timezone.utc
        ),
        messages_sent_today=0,
    )

    assert result["approved"] is False
    assert "quiet_hours" in result["failed"]


def test_frequency_cap():
    result = verify_action(
        action="PUSH",
        is_holdout=False,
        has_consent=True,
        decision_time=datetime(
            2026, 10, 19, 6, 0,
            tzinfo=timezone.utc
        ),
        messages_sent_today=1,
    )

    assert result["approved"] is False
    assert "frequency_cap" in result["failed"]


def test_valid_message():
    result = verify_action(
        action="PUSH",
        is_holdout=False,
        has_consent=True,
        decision_time=datetime(
            2026, 10, 19, 6, 0,
            tzinfo=timezone.utc
        ),
        messages_sent_today=0,
    )

    assert result["approved"] is True
    assert result["failed"] == []
