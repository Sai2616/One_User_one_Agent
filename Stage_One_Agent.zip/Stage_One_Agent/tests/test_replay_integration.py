
import json
from datetime import datetime, timezone

from src.replay_integration import evaluate_viewer_goal


def test_viewer_gets_a_planned_goal(tmp_path):
    goals_file = tmp_path / "goals.json"

    goals_file.write_text(
        json.dumps({
            "goals": [
                {
                    "id": "complete_episode",
                    "eligibility": {"signed_up": True},
                    "success_signal": "episode_completed",
                }
            ]
        }),
        encoding="utf-8",
    )

    result = evaluate_viewer_goal(
        viewer_id="user_101",
        viewer_facts={"signed_up": True},
        measurable_signals={"episode_completed"},
        window_days_by_goal={"complete_episode": 3},
        goals_file=goals_file,
        start_time=datetime(
            2026, 10, 19, 10, 0, tzinfo=timezone.utc
        ),
    )

    assert result["selection"]["status"] == "ELIGIBLE"
    assert result["goal_plan"]["status"] == "PLANNED"
    assert result["goal_plan"]["goal"]["id"] == "complete_episode"


def test_missing_goal_window_abstains(tmp_path):
    goals_file = tmp_path / "goals.json"

    goals_file.write_text(
        json.dumps({
            "goals": [
                {
                    "id": "complete_episode",
                    "eligibility": {"signed_up": True},
                    "success_signal": "episode_completed",
                }
            ]
        }),
        encoding="utf-8",
    )

    result = evaluate_viewer_goal(
        viewer_id="user_101",
        viewer_facts={"signed_up": True},
        measurable_signals={"episode_completed"},
        window_days_by_goal={},
        goals_file=goals_file,
        start_time=datetime(
            2026, 10, 19, 10, 0, tzinfo=timezone.utc
        ),
    )

    assert result["goal_plan"]["status"] == "NO_GOAL"
    assert "window" in result["goal_plan"]["reason"]


def test_ineligible_viewer_does_not_get_a_goal(tmp_path):
    goals_file = tmp_path / "goals.json"

    goals_file.write_text(
        json.dumps({
            "goals": [
                {
                    "id": "complete_episode",
                    "eligibility": {"signed_up": True},
                    "success_signal": "episode_completed",
                }
            ]
        }),
        encoding="utf-8",
    )

    result = evaluate_viewer_goal(
        viewer_id="user_102",
        viewer_facts={"signed_up": False},
        measurable_signals={"episode_completed"},
        window_days_by_goal={"complete_episode": 3},
        goals_file=goals_file,
        start_time=datetime(
            2026, 10, 19, 10, 0, tzinfo=timezone.utc
        ),
    )

    assert result["goal_plan"]["status"] == "NO_GOAL"
