
from datetime import datetime, timezone

from src.decision_engine import build_decision_record


def test_rejected_action_becomes_no_action():
    record = build_decision_record(
        viewer_id="user_101",
        trigger_event_id="event_abc",
        goal_plan={
            "status": "PLANNED",
            "goal": {"id": "goal_1"},
            "deadline": "2026-10-22T10:00:00Z",
            "success_signal": "episode_completed",
        },
        intervention={
            "action": "PUSH",
            "reason": "Recommend an episode",
        },
        verification={
            "approved": False,
            "passed": [],
            "failed": ["consent"],
        },
        decision_time=datetime(
            2026, 10, 19, 10, 0, tzinfo=timezone.utc
        ),
    )

    assert record["action"] == "NO_ACTION"
    assert record["status"] == "NO_ACTION"
    assert record["no_action_reason"] == (
        "Independent verification did not approve the action."
    )


def test_approved_action_is_not_marked_delivered():
    record = build_decision_record(
        viewer_id="user_101",
        trigger_event_id="event_def",
        goal_plan={
            "status": "PLANNED",
            "goal": {"id": "goal_1"},
            "deadline": "2026-10-22T10:00:00Z",
            "success_signal": "episode_completed",
        },
        intervention={
            "action": "HOME_PAGE",
            "reason": "Personalize content",
            "content": ["title_1", "title_2", "title_3"],
        },
        verification={
            "approved": True,
            "passed": ["eligibility", "dialect"],
            "failed": [],
        },
    )

    assert record["action"] == "HOME_PAGE"
    assert record["status"] == "READY_FOR_EXECUTION"
    assert "delivered" not in record
    assert record["goal"]["id"] == "goal_1"
    assert record["checks"]["failed"] == []
