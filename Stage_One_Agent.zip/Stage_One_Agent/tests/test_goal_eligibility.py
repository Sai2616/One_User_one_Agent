
from src.goal_planner import (
    check_goal_eligibility,
    select_measurable_goal,
)


def test_goal_is_eligible_when_rules_and_signal_match():
    goal = {
        "id": "goal_example",
        "eligibility": {"signed_up": True},
        "success_signal": "episode_completed",
    }

    result = check_goal_eligibility(
        goal,
        viewer_facts={"signed_up": True},
        measurable_signals={"episode_completed"},
    )

    assert result["eligible"] is True


def test_missing_success_signal_rejects_goal():
    goal = {
        "id": "goal_example",
        "eligibility": {"signed_up": True},
        "success_signal": "payment_completed",
    }

    result = check_goal_eligibility(
        goal,
        viewer_facts={"signed_up": True},
        measurable_signals={"episode_completed"},
    )

    assert result["eligible"] is False
    assert "not available" in result["reason"]


def test_missing_viewer_fact_rejects_goal():
    goal = {
        "id": "goal_example",
        "eligibility": {"signed_up": True},
        "success_signal": "episode_completed",
    }

    result = check_goal_eligibility(
        goal,
        viewer_facts={},
        measurable_signals={"episode_completed"},
    )

    assert result["eligible"] is False
    assert "missing" in result["reason"]


def test_no_eligible_goal_returns_no_goal():
    goals = [
        {
            "id": "goal_example",
            "eligibility": {"signed_up": True},
            "success_signal": "episode_completed",
        }
    ]

    result = select_measurable_goal(
        goals,
        viewer_facts={"signed_up": False},
        measurable_signals={"episode_completed"},
    )

    assert result["status"] == "NO_GOAL"
    assert result["goal"] is None
