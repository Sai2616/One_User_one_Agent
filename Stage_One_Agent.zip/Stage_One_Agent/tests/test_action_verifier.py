
from datetime import datetime, timezone

from src.action_verifier import verify_proposed_action


def test_valid_homepage_is_approved():
    result = verify_proposed_action(
        action="HOME_PAGE",
        decision_time=datetime(
            2026, 10, 19, 10, 0, tzinfo=timezone.utc
        ),
        is_holdout=False,
        goal_eligible=True,
    )

    assert result["approved"] is True


def test_holdout_cannot_receive_action():
    result = verify_proposed_action(
        action="HOME_PAGE",
        decision_time=datetime.now(timezone.utc),
        is_holdout=True,
        goal_eligible=True,
    )

    assert result["approved"] is False
    assert "holdout" in result["failed"]


def test_push_requires_consent():
    result = verify_proposed_action(
        action="PUSH",
        decision_time=datetime(
            2026, 10, 19, 10, 0, tzinfo=timezone.utc
        ),
        is_holdout=False,
        goal_eligible=True,
        push_consent=False,
        messages_sent_today=0,
    )

    assert result["approved"] is False
    assert "consent" in result["failed"]


def test_duplicate_action_is_rejected():
    result = verify_proposed_action(
        action="HOME_PAGE",
        decision_time=datetime.now(timezone.utc),
        is_holdout=False,
        goal_eligible=True,
        duplicate_action=True,
    )

    assert result["approved"] is False
    assert "duplicate_action" in result["failed"]


def test_unknown_holdout_status_is_rejected():
    result = verify_proposed_action(
        action="HOME_PAGE",
        decision_time=datetime.now(timezone.utc),
        is_holdout=None,
        goal_eligible=True,
    )

    assert result["approved"] is False
    assert "holdout_status_unknown" in result["failed"]
