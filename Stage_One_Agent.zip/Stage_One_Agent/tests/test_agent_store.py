
from src.agent_store import AgentStore


def test_viewer_state_persists(tmp_path):
    db_path = tmp_path / "test.db"

    store = AgentStore(db_path)
    state = {"dialect": "Telugu", "active_goal": "completion"}

    store.save_viewer_state("user_101", state)

    # Create another store to simulate reopening the application.
    reopened_store = AgentStore(db_path)

    assert reopened_store.get_viewer_state("user_101") == state


def test_unknown_viewer_returns_none(tmp_path):
    store = AgentStore(tmp_path / "test.db")

    assert store.get_viewer_state("new_user") is None


def test_duplicate_trigger_is_not_recorded_twice(tmp_path):
    store = AgentStore(tmp_path / "test.db")

    decision = {"action": "HOME_PAGE"}

    first = store.record_decision(
        "user_101", "event_abc", decision
    )
    second = store.record_decision(
        "user_101", "event_abc", decision
    )

    assert first is True
    assert second is False

    history = store.get_decisions("user_101")
    assert len(history) == 1


def test_different_users_can_use_same_event_id(tmp_path):
    store = AgentStore(tmp_path / "test.db")

    decision = {"action": "NO_ACTION"}

    assert store.record_decision(
        "user_101", "event_abc", decision
    ) is True

    assert store.record_decision(
        "user_202", "event_abc", decision
    ) is True
