
from src.data_loader import deduplicate_events


def test_duplicate_event_id_is_removed():
    events = [
        {
            "event_id": "E101",
            "received_at": "2026-10-18T10:00:00Z",
        },
        {
            "event_id": "E101",
            "received_at": "2026-10-18T10:00:00Z",
        },
        {
            "event_id": "E102",
            "received_at": "2026-10-18T10:05:00Z",
        },
    ]

    result, duplicates = deduplicate_events(events)

    assert len(result) == 2
    assert duplicates == 1


def test_earliest_received_record_is_kept():
    events = [
        {
            "event_id": "E101",
            "received_at": "2026-10-18T10:05:00Z",
        },
        {
            "event_id": "E101",
            "received_at": "2026-10-18T10:00:00Z",
        },
    ]

    result, duplicates = deduplicate_events(events)

    assert len(result) == 1
    assert duplicates == 1
    assert result[0]["received_at"] == "2026-10-18T10:00:00Z"
