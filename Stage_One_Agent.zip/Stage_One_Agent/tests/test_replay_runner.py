
import json

import pytest

from src.replay_runner import run_replay


def write_events(path, events):
    """Write test events in JSONL format."""
    with path.open("w", encoding="utf-8") as file:
        for event in events:
            file.write(json.dumps(event) + "\n")


def read_jsonl(path):
    """Read JSONL records from a file."""
    with path.open("r", encoding="utf-8") as file:
        return [
            json.loads(line)
            for line in file
            if line.strip()
        ]


def make_event(
    event_id="e1",
    user_id="u1",
    event_name="app_open",
    received_at="2026-10-19T10:00:00Z",
):
    return {
        "event_id": event_id,
        "user_id": user_id,
        "event": event_name,
        "received_at": received_at,
        "occurred_at": received_at,
        "app_dialect": "Telugu",
        "properties": {},
    }


def test_replay_writes_one_record_per_trigger(tmp_path):
    events_file = tmp_path / "events.jsonl"
    output_file = tmp_path / "decisions.jsonl"

    write_events(
        events_file,
        [
            make_event("e1", "u1", "app_open"),
            make_event(
                "e2",
                "u1",
                "episode_play",
                "2026-10-19T10:01:00Z",
            ),
        ],
    )

    summary = run_replay(events_file, output_file)
    records = read_jsonl(output_file)

    assert summary["events_loaded"] == 2
    assert summary["unique_events"] == 2
    assert summary["app_open_triggers"] == 1
    assert summary["records_written"] == 1

    assert len(records) == 1
    assert records[0]["trigger_event_id"] == "e1"
    assert records[0]["viewer_id"] == "u1"
    assert records[0]["status"] == "NOT_EVALUATED"
    assert records[0]["mode"] == "simulation"


def test_duplicate_event_id_is_processed_once(tmp_path):
    events_file = tmp_path / "events.jsonl"
    output_file = tmp_path / "decisions.jsonl"

    event = make_event("e1", "u1")

    write_events(events_file, [event, event.copy()])

    summary = run_replay(events_file, output_file)
    records = read_jsonl(output_file)

    assert summary["events_loaded"] == 2
    assert summary["unique_events"] == 1
    assert summary["app_open_triggers"] == 1
    assert len(records) == 1


def test_event_name_is_case_and_whitespace_tolerant(tmp_path):
    events_file = tmp_path / "events.jsonl"
    output_file = tmp_path / "decisions.jsonl"

    write_events(
        events_file,
        [make_event("e1", "u1", " App_Open ")],
    )

    summary = run_replay(events_file, output_file)

    assert summary["app_open_triggers"] == 1
    assert summary["records_written"] == 1


def test_invalid_timestamp_is_skipped(tmp_path):
    events_file = tmp_path / "events.jsonl"
    output_file = tmp_path / "decisions.jsonl"

    write_events(
        events_file,
        [make_event(received_at="not-a-timestamp")],
    )

    summary = run_replay(events_file, output_file)

    assert summary["app_open_triggers"] == 0
    assert summary["records_written"] == 0
    assert read_jsonl(output_file) == []


def test_missing_user_id_is_skipped(tmp_path):
    events_file = tmp_path / "events.jsonl"
    output_file = tmp_path / "decisions.jsonl"

    write_events(
        events_file,
        [make_event(user_id="")],
    )

    summary = run_replay(events_file, output_file)

    assert summary["app_open_triggers"] == 0
    assert read_jsonl(output_file) == []


def test_empty_file_produces_empty_output(tmp_path):
    events_file = tmp_path / "events.jsonl"
    output_file = tmp_path / "decisions.jsonl"

    events_file.write_text("", encoding="utf-8")

    summary = run_replay(events_file, output_file)

    assert summary["events_loaded"] == 0
    assert summary["app_open_triggers"] == 0
    assert summary["records_written"] == 0
    assert read_jsonl(output_file) == []


def test_missing_input_file_raises_clear_error(tmp_path):
    events_file = tmp_path / "missing.jsonl"
    output_file = tmp_path / "decisions.jsonl"

    with pytest.raises(FileNotFoundError, match="Events file not found"):
        run_replay(events_file, output_file)


def test_triggers_are_sorted_by_received_at(tmp_path):
    events_file = tmp_path / "events.jsonl"
    output_file = tmp_path / "decisions.jsonl"

    write_events(
        events_file,
        [
            make_event(
                "e2", "u1", "app_open",
                "2026-10-19T10:02:00Z",
            ),
            make_event(
                "e1", "u1", "app_open",
                "2026-10-19T10:01:00Z",
            ),
        ],
    )

    run_replay(events_file, output_file)
    records = read_jsonl(output_file)

    assert [
        record["trigger_event_id"] for record in records
    ] == ["e1", "e2"]
