
from src.homepage_builder import build_homepage


def title(title_id, slug):
    return {
        "title_id": title_id,
        "content_slug": slug,
    }


def test_drops_rows_with_fewer_than_three_titles():
    hero = title("T1", "hero")

    result = build_homepage(
        hero,
        [
            {
                "type": "genre",
                "titles": [
                    title("T2", "movie-a"),
                    title("T3", "movie-b"),
                ],
            }
        ],
    )

    assert result["row_count"] == 0


def test_deduplicates_slugs_across_page():
    hero = title("T1", "hero")

    result = build_homepage(
        hero,
        [
            {
                "type": "genre",
                "titles": [
                    title("T2", "movie-a"),
                    title("T3", "movie-b"),
                    title("T4", "movie-c"),
                ],
            },
            {
                "type": "new_releases",
                "titles": [
                    title("T5", "movie-a"),
                    title("T6", "movie-d"),
                    title("T7", "movie-e"),
                ],
            },
        ],
    )

    assert result["row_count"] == 1
    assert len(result["rows"][0]["titles"]) == 3


def test_rejects_continue_watching_row_type():
    hero = title("T1", "hero")

    result = build_homepage(
        hero,
        [
            {
                "type": "continue_watching",
                "titles": [
                    title("T2", "movie-a"),
                    title("T3", "movie-b"),
                    title("T4", "movie-c"),
                ],
            }
        ],
    )

    assert result["row_count"] == 0


def test_rejects_missing_hero():
    result = build_homepage(None, [])

    assert result["status"] == "REJECTED"
