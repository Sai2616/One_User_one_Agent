
import json

from src.goal_config_loader import load_goal_config


def test_load_goal_list(tmp_path):
    path = tmp_path / "goals.json"

    path.write_text(
        json.dumps({
            "goals": [
                {"id": "goal_1"},
                {"id": "goal_2"},
            ]
        }),
        encoding="utf-8",
    )

    goals = load_goal_config(path)

    assert len(goals) == 2
    assert goals[0]["id"] == "goal_1"


def test_invalid_json_raises_clear_error(tmp_path):
    path = tmp_path / "goals.json"
    path.write_text("{invalid json", encoding="utf-8")

    try:
        load_goal_config(path)
    except ValueError as exc:
        assert "Invalid JSON" in str(exc)
    else:
        raise AssertionError("Expected invalid JSON to be rejected.")
