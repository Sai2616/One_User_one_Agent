
from datetime import datetime, timezone

from src.goal_planner import create_goal_plan_from_selection


def test_eligible_goal_creates_deadline():
    start = datetime(2026, 10, 19, 10, 0, tzinfo=timezone.utc)

    selection = {
        "status": "ELIGIBLE",
        "goal": {
            "id": "goal_example",
            "success_signal": "episode_completed",
        },
    }

    result = create_goal_plan_from_selection(
        selection,
        start,
        3,
    )

    assert result["status"] == "PLANNED"
    assert result["deadline"] == "2026-10-22T10:00:00+00:00"
    assert result["success_signal"] == "episode_completed"


def test_no_goal_selection_does_not_create_plan():
    result = create_goal_plan_from_selection(
        {
            "status": "NO_GOAL",
            "reason": "Insufficient evidence.",
        },
        datetime(2026, 10, 19, 10, 0, tzinfo=timezone.utc),
        3,
    )

    assert result["status"] == "NO_GOAL"


def test_naive_start_time_is_rejected():
    result = create_goal_plan_from_selection(
        {
            "status": "ELIGIBLE",
            "goal": {
                "id": "goal_example",
                "success_signal": "episode_completed",
            },
        },
        datetime(2026, 10, 19, 10, 0),
        3,
    )

    assert result["status"] == "NO_GOAL"


def test_invalid_window_is_rejected():
    result = create_goal_plan_from_selection(
        {
            "status": "ELIGIBLE",
            "goal": {
                "id": "goal_example",
                "success_signal": "episode_completed",
            },
        },
        datetime(2026, 10, 19, 10, 0, tzinfo=timezone.utc),
        0,
    )

    assert result["status"] == "NO_GOAL"
