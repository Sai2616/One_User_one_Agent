
from datetime import datetime, timezone

from src.agent_pipeline import process_goal_decision


def test_valid_goal_and_approved_action():
    start = datetime(2026, 10, 19, 10, 0, tzinfo=timezone.utc)

    result = process_goal_decision(
        viewer_id="user_101",
        trigger_event_id="event_001",
        selection={
            "status": "ELIGIBLE",
            "goal": {
                "id": "goal_1",
                "success_signal": "episode_completed",
            },
        },
        window_days=3,
        intervention={
            "action": "HOME_PAGE",
            "reason": "Personalize the home page",
        },
        verification={
            "approved": True,
            "passed": ["eligibility", "dialect"],
            "failed": [],
        },
        start_time=start,
    )

    assert result["goal_plan"]["status"] == "PLANNED"
    assert result["decision"]["action"] == "HOME_PAGE"
    assert result["decision"]["status"] == "READY_FOR_EXECUTION"
    assert result["decision"]["goal"]["id"] == "goal_1"


def test_missing_goal_results_in_no_action():
    start = datetime(2026, 10, 19, 10, 0, tzinfo=timezone.utc)

    result = process_goal_decision(
        viewer_id="user_102",
        trigger_event_id="event_002",
        selection={
            "status": "NO_GOAL",
            "reason": "Insufficient evidence.",
        },
        window_days=3,
        intervention={
            "action": "HOME_PAGE",
            "reason": "Personalize the home page",
        },
        verification={
            "approved": True,
            "passed": [],
            "failed": [],
        },
        start_time=start,
    )

    assert result["goal_plan"]["status"] == "NO_GOAL"
    assert result["decision"]["action"] == "NO_ACTION"
    assert result["decision"]["status"] == "NO_ACTION"


def test_rejected_action_results_in_no_action():
    result = process_goal_decision(
        viewer_id="user_103",
        trigger_event_id="event_003",
        selection={
            "status": "ELIGIBLE",
            "goal": {
                "id": "goal_1",
                "success_signal": "episode_completed",
            },
        },
        window_days=3,
        intervention={
            "action": "PUSH",
            "reason": "Recommend an episode",
        },
        verification={
            "approved": False,
            "passed": [],
            "failed": ["consent"],
        },
        start_time=datetime(
            2026, 10, 19, 10, 0, tzinfo=timezone.utc
        ),
    )

    assert result["decision"]["action"] == "NO_ACTION"
    assert result["decision"]["status"] == "NO_ACTION"
