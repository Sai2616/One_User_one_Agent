
from src.user_state import build_user_state


def test_build_state_for_new_user_without_profile():
    events = [
        {
            "event_id": "E1",
            "user_id": "U100",
            "event": "signup_completed",
            "received_at": "2026-10-19T09:00:00Z",
        }
    ]

    state = build_user_state(
        "U100",
        profiles_by_user={},
        events=events,
    )

    assert state["user_id"] == "U100"
    assert state["profile"] is None
    assert state["event_count"] == 1
    assert state["events"][0]["event"] == "signup_completed"


def test_state_does_not_include_another_users_events():
    events = [
        {"event_id": "E1", "user_id": "U100", "event": "app_open"},
        {"event_id": "E2", "user_id": "U200", "event": "app_open"},
    ]

    state = build_user_state("U100", {}, events)

    assert state["event_count"] == 1
    assert state["events"][0]["user_id"] == "U100"
