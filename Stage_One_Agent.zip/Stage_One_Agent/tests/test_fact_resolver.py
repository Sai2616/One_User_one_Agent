
from src.fact_resolver import resolve_dialect


def test_app_setting_wins_and_conflict_is_recorded():
    result = resolve_dialect("d3", "d1")

    assert result["value"] == "d3"
    assert result["source"] == "app_setting"
    assert len(result["conflicts"]) == 1


def test_profile_is_fallback():
    result = resolve_dialect(None, "d2")

    assert result["value"] == "d2"
    assert result["source"] == "profile"


def test_missing_dialect_returns_none():
    result = resolve_dialect(None, None)

    assert result["value"] is None
    assert result["source"] is None
