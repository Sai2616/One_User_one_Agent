
from datetime import datetime, timezone

from src.verified_decision import build_verified_decision


NOW = datetime(2026, 10, 19, 12, 0, tzinfo=timezone.utc)

VALID_GOAL = {
    "status": "PLANNED",
    "goal_id": "goal_01",
}


def make_decision(**overrides):
    values = {
        "viewer_id": "viewer_001",
        "trigger_event_id": "event_001",
        "goal_plan": VALID_GOAL,
        "proposed_action": "HOME_PAGE",
        "decision_time": NOW,
        "is_holdout": False,
        "dialect": "Telangana Telugu",
        "content": {"title_id": "title_01"},
        "duplicate_action": False,
        "policy_approved": True,
    }
    values.update(overrides)
    return build_verified_decision(**values)


def test_approved_homepage_is_ready():
    decision = make_decision()

    assert decision["action"] == "HOME_PAGE"
    assert decision["status"] == "READY_FOR_EXECUTION"
    assert decision["execution_status"] == "NOT_EXECUTED"


def test_holdout_becomes_no_action():
    decision = make_decision(is_holdout=True)

    assert decision["action"] == "NO_ACTION"
    assert decision["status"] == "NO_ACTION"
    assert "holdout" in decision["no_action_reason"]


def test_push_without_consent_becomes_no_action():
    decision = make_decision(
        proposed_action="PUSH",
        push_consent=False,
        messages_sent_today=0,
    )

    assert decision["action"] == "NO_ACTION"
    assert "consent" in decision["no_action_reason"]


def test_unplanned_goal_becomes_no_action():
    decision = make_decision(
        goal_plan={"status": "INELIGIBLE", "goal_id": "goal_01"}
    )

    assert decision["action"] == "NO_ACTION"
    assert "goal_eligibility" in decision["no_action_reason"]


def test_unknown_holdout_status_becomes_no_action():
    decision = make_decision(is_holdout=None)

    assert decision["action"] == "NO_ACTION"
    assert "holdout_status_unknown" in decision["no_action_reason"]
